/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;

import java.util.Objects;
/**
 *
 * @author coter
 */
public class Revista extends Trabajo {
    private int numeroEdicion;

    public Revista() { 
    }

    public Revista(String titulo, String autor, int anioPublicacion, int numeroEdicion) {
        super(titulo, autor, anioPublicacion);
        this.numeroEdicion = numeroEdicion;
    }

    public int getNumeroEdicion() { 
        return numeroEdicion; 
    }
    public void setNumeroEdicion(int numeroEdicion) { 
        this.numeroEdicion = numeroEdicion; 
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), numeroEdicion);
    }
    
    @Override
    public boolean equals(Object o) {
        if (!super.equals(o)) return false;
        Revista r = (Revista) o;
        return numeroEdicion == r.numeroEdicion;
    }

    @Override
    public String toString() {
        return "[REVISTA] " + super.toString() + " | Edición: " + numeroEdicion;
    }
}//Final
