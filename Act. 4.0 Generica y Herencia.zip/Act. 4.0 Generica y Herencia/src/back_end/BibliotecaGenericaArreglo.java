/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;
/**
 *
 * @author coter
 */
public class BibliotecaGenericaArreglo<T extends Trabajo> {

    private final T[] arreglo;
    private final int capacidad;
    private int contador;

    @SuppressWarnings("unchecked")
    public BibliotecaGenericaArreglo(int capacidad) {
        if (capacidad <= 0) {
            throw new IllegalArgumentException("La capacidad debe ser mayor a cero");
        }
        this.capacidad = capacidad;
        this.arreglo = (T[]) new Trabajo[capacidad]; // creación segura del arreglo genérico
        this.contador = 0;
    }

    public int getCapacidad() { 
        return capacidad; 
    }
    public int getContador() { 
        return contador; 
    }

// agregarTrabajo(T trabajo, int posicion):
    public void agregarTrabajo(T trabajo, int posicion) {
        if (trabajo == null) {
            throw new IllegalArgumentException("El trabajo no puede ser nulo");
        }
        if (!posicionValida(posicion)) {
            throw new IndexOutOfBoundsException("Posición inválida. Debe estar entre 1 y " + (capacidad));
        }
        if (arreglo[posicion] != null) {
            throw new IllegalStateException("La posición " + (posicion + 1) + " ya está ocupada. Elimine el registro primero");
        }
        arreglo[posicion] = trabajo;
        contador++;
    }

// eliminarTrabajo(int posicion): 
    public T eliminarTrabajo(int posicion) {
        if (!posicionValida(posicion)) {
            throw new IndexOutOfBoundsException("Posición inválida. Debe estar entre 1 y " + (capacidad - 1));
        }
        if (arreglo[posicion] == null) {
            throw new IllegalStateException("La posición " + posicion + " ya está vacía");
        }
        T eliminado = arreglo[posicion];
        arreglo[posicion] = null;
        contador--;
        return eliminado;
    }
    
// mostrarTrabajo(int posicion): 
    public T mostrarTrabajo(int posicion) {
        if (!posicionValida(posicion)) {
            throw new IndexOutOfBoundsException(
                    "Posición inválida. Debe estar entre 0 y " + (capacidad - 1) + ".");
        }
        if (arreglo[posicion] == null) {
            throw new IllegalStateException("La posición " + posicion + " está vacía.");
        }
        return arreglo[posicion];
    }

// mostrarTodosTrabajos():
    public String mostrarTodosTrabajos() {
        if (isEmpty()) {
            return "La biblioteca está vacía.";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < capacidad; i++) {
            sb.append("[").append(i + 1).append("] ");
            if (arreglo[i] == null) {
                sb.append("-- (vacío) --\n");
            } else {
                sb.append(arreglo[i].toString()).append("\n");
            }
        }
        return sb.toString();
    }

// vaciarBiblioteca(): 
    public void vaciarBiblioteca() {
        for (int i = 0; i < capacidad; i++) {
            arreglo[i] = null;
        }
        contador = 0;
    }

// isEmpty():   
    public boolean isEmpty() {
        return contador == 0;
    }
    
// metodos auxiliares
    public boolean posicionValida(int posicion) {
        return posicion >= 0 && posicion < capacidad;
    }

    public boolean estaOcupada(int posicion) {
        return posicionValida(posicion) && arreglo[posicion] != null;
    }
}//Final
